from ..reader import *

def write():
	print('barcode screen:', barcode.data)
	print('qrcode screen:', qrcode.data)