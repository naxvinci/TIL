from ..reader import *

def write():
	print('barcode print:', barcode.data)
	print('qrcode print:', qrcode.data)