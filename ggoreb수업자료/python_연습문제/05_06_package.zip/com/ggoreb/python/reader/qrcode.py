data = ''
def read(num):
	global data
	data = str(num)
	print('qrcode reader:', data)